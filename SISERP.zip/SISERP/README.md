# SISERP

Point of sales Application using Flutter + Firebase Database
Supported and Integrated with Website Admin using CodeIgniter

Feature:
- Master Stock
- Master Category
- Master Supplier
- Master Cashier
- Master Promo + Emailing Promo to customer
- Master Return Stock
- Master Return Transaction
- Transaction
- Detail Member
- Detail Transaction
- Editing Store Profile
- Support QR/Barcode
- Payment using Debit/VAC/Credit Card(Midtrans)
- Report in website
- Printing Receipt using POS Printer(Tested using TM-u220 Dot Matrix Epson)

RB

